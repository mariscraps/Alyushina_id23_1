import pytest
import time
import base64
from app.tasks import async_encode
from app.core.celery import celery_app
from celery.result import AsyncResult
from app.services.encoding import HuffmanEncoder, XORCipher


@pytest.fixture
def celery_config():
    return {
        'broker_url': 'redis://localhost:6379/0',
        'result_backend': 'redis://localhost:6379/0'
    }


def decode_huffman(bit_string, huffman_codes, padding):
    """Улучшенная функция декодирования для одинаковых символов"""
    if not bit_string or not huffman_codes:
        return ""

    if padding > 0:
        bit_string = bit_string[:-padding]

    # Особый случай: все символы одинаковые
    if len(huffman_codes) == 1:
        char = next(iter(huffman_codes.values()))
        return char * len(bit_string)

    decoded = []
    current_code = ""
    inv_codes = {v: k for k, v in huffman_codes.items()}

    for bit in bit_string:
        current_code += bit
        if current_code in inv_codes:
            decoded.append(inv_codes[current_code])
            current_code = ""

    return ''.join(decoded)


@pytest.mark.parametrize("text,key", [
    ("TEST", "key"),  # Базовый случай
    ("", "empty"),  # Пустая строка
    ("a", "key"),  # Один символ
    ("aaaaa", "key"),  # Одинаковые символы
    ("Hello World!", "key"),  # Обычный текст
    ("@#$%^", "key"),  # Спецсимволы
    ("12345", "key"),  # Цифры
    ("\x00\x01", "bin")  # Бинарные данные
])
def test_encode_decode_roundtrip(text, key):
    """Проверка полного цикла кодирования-декодирования"""
    # 1. Отправляем задачу в Celery
    task = async_encode.delay(text, key)
    result = AsyncResult(task.id, app=celery_app)

    # 2. Ждём выполнения с таймаутом
    for _ in range(10):
        if result.ready():
            break
        time.sleep(0.5)
    else:
        pytest.fail("Timeout: задача не выполнилась за 5 секунд")

    assert result.successful(), f"Ошибка выполнения: {result.traceback}"
    task_result = result.get()

    # 3. Проверяем структуру результата
    assert all(k in task_result for k in
               ['encoded_data', 'key', 'huffman_codes', 'padding'])

    # 4. Пропускаем декодирование для пустой строки
    if not text:
        assert task_result['encoded_data'] == ""
        return

    # 5. Процесс декодирования
    try:
        # 5.1. Base64 декодинг
        encrypted = base64.b64decode(task_result['encoded_data']).decode(
            'latin-1')

        # 5.2. XOR расшифровка
        decrypted = XORCipher.xor_decrypt(encrypted, task_result['key'])

        # 5.3. Получаем битовую строку
        bit_string = ''.join(f"{ord(c):08b}" for c in decrypted)

        # 5.4. Декодирование Хаффмана
        decoded_text = decode_huffman(bit_string, task_result['huffman_codes'],
                                      task_result['padding'])

        assert decoded_text == text, (
            f"Ошибка декодирования:\n"
            f"Ожидалось: {text!r}\n"
            f"Получено: {decoded_text!r}\n"
            f"Коды: {task_result['huffman_codes']}\n"
            f"Биты: {bit_string}\n"
            f"Паддинг: {task_result['padding']}"
        )
    except Exception as e:
        pytest.fail(f"Ошибка при декодировании: {str(e)}")


def test_concurrent_execution():
    """Тест параллельного выполнения с улучшенной проверкой"""
    from concurrent.futures import ThreadPoolExecutor

    texts = ["TASK1", "TASK2", "TASK3"]
    key = "concurrent_key"
    results = []

    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(async_encode.delay, text, key) for text in
                   texts]
        for future in futures:
            task = future.result()
            result = AsyncResult(task.id, app=celery_app)
            results.append(result.get(timeout=10))

    # Проверяем что все результаты корректны
    for res in results:
        assert isinstance(res, dict)
        assert all(k in res for k in
                   ['encoded_data', 'key', 'huffman_codes', 'padding'])
        if res['key'] == key:  # Дополнительная проверка ключа
            assert True


if __name__ == "__main__":
    pytest.main(["-v", "tests/test_celery.py"])

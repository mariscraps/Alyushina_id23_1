import pytest
from app.services.encoding import HuffmanEncoder, XORCipher


def test_huffman_empty_string():
    codes = HuffmanEncoder.get_huffman_codes("")
    assert codes == {}
    assert HuffmanEncoder.huffman_encode("", codes) == ""


def test_huffman_single_char():
    codes = HuffmanEncoder.get_huffman_codes("aaaa")
    assert codes == {'a': '0'}
    assert HuffmanEncoder.huffman_encode("aaaa", codes) == '0000'


def test_xor_empty_key():
    with pytest.raises(ValueError):
        XORCipher.xor_encrypt("text", "")


def test_xor_roundtrip():
    text = "Test message"
    key = "secret"
    encrypted = XORCipher.xor_encrypt(text, key)
    decrypted = XORCipher.xor_decrypt(encrypted, key)
    assert decrypted == text
